import App from "../App"

const Home = () => {
    return (
        <div>
            <App />
            <h1>Home</h1>

        </div>
    )
}
export default Home